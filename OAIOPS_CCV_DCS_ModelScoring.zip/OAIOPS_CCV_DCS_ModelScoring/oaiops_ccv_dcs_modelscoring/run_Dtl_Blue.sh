#!/usr/bin/env bash
set -vx
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

dtl_JAR_NAME=$1
ENV=$2
SOURCE_DB=$3
TARGET_DB=$4
outputLocation=$5

#hdfs dfs -get /mlprod/unrestricted/JarRepo/FL/${dtl_JAR_NAME}

hdfs dfs -get /mlprod/unrestricted/JarRepo/FL/fl-coe-dtl-revflags-0.0.2.jar

spark-submit --master yarn --queue production --deploy-mode cluster --num-executors 30 --driver-memory 9G --executor-memory 12G --executor-cores 4 --total-executor-cores 120 --class com.cotiviti.ai.fl.revfeatures.RevFeatures ${dtl_JAR_NAME} dcs hive ${SOURCE_DB}.tcube3_dtl ${outputLocation}COE_DTL_RevFlags_dcs_score


#hdfs dfs -get svcdml.keytab

#/usr/bin/kinit -kt svcdml.keytab -V svcdml@COTIVITI.COM
/usr/bin/kinit -kt svcdataml.keytab -V svcdataml@COTIVITI.COM

PARQ_LOC="${outputLocation}COE_DTL_RevFlags_dcs_score/*.parquet"
ParFileName=`hadoop fs -ls $PARQ_LOC | awk -F'/' '{print $NF}' | head -n 1`
DestDB="ml_ccv_${ENV}"
FOLDER_NAME_Dtl="TCUBE3_Dtl_Blue"

impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Dtl} PURGE;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Dtl} LIKE PARQUET '${outputLocation}COE_DTL_RevFlags_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}COE_DTL_RevFlags_dcs_score' ;"
