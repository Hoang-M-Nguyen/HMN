#!/usr/bin/env bash
set -vx
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM



diag_JAR_NAME=$1
ENV=$2
SOURCE_DB=$3
TARGET_DB=$4
outputLocation=$5
csv_path=$6



#hdfs dfs -get /mlprod/unrestricted/JarRepo/FL/${diag_JAR_NAME}



spark-submit --master yarn --queue production --deploy-mode cluster --num-executors 30 --driver-memory 9G --executor-memory 12G --executor-cores 4 --total-executor-cores 120 --class com.cotiviti.ai.fl.mapping.CCSR_DX ${diag_JAR_NAME} dcs hive ${SOURCE_DB}.tcube3_diag ${csv_path}/CCSRDX/DXCCSR_v2021-2.csv  ${outputLocation}COE_DX_CCSR20212_dcs_score


#/usr/bin/kinit -kt svcdml.keytab -V svcdml@COTIVITI.COM

/usr/bin/kinit -kt svcdataml.keytab -V svcdataml@COTIVITI.COM


hdfs dfs -ls ${outputLocation}COE_DX_CCSR20212_dcs_score/
echo $outputLocation



PARQ_LOC="${outputLocation}COE_DX_CCSR20212_dcs_score/*.parquet"
ParFileName=`hadoop fs -ls $PARQ_LOC | awk -F'/' '{print $NF}' | head -n 1`
DestDB="ml_ccv_$ENV"
FOLDER_NAME_Diag="TCUBE3_Diag_Blue"



impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Diag} PURGE;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Diag} LIKE PARQUET '${outputLocation}COE_DX_CCSR20212_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}COE_DX_CCSR20212_dcs_score' ;"


#beeline -u "jdbc:hive2://gad1phdpml03.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" -e "drop table if exists $DestDB.$FOLDER_NAME_Diag purge;"
#beeline -u "jdbc:hive2://gad1phdpml03.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" -e "create table $DestDB.$FOLDER_NAME_Diag as select * from $DestDB.$FOLDER_NAME_Diag ;"
#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata ${DestDB}.${FOLDER_NAME_Diag};"



#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Diag} PURGE;"
#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "invalidate metadata;"
#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Diag} LIKE PARQUET '${outputLocation}COE_DX_CCSR20212_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}COE_DX_CCSR20212_dcs_score' ;"