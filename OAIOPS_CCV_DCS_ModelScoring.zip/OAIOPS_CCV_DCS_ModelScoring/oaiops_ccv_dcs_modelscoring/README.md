This Script runs the Sepsis Model.. You need to setup this piece as well as the pieces on the R server.

replace svcpml with your name, and this should execute fine.

Readme for easy workflow setup is below:

hdfs dfs -mkdir /projects/ard_ccv_project/DCS/Code/
hdfs dfs -mkdir /projects/ard_ccv_project/DCS/Code/SepsisModel


hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.xml
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.xml /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.jar
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.jar /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.pig
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.pig /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.txt
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.txt /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.json
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.json /projects/ard_ccv_project/DCS/Code/SepsisModel/


hdfs dfs -rm -skipTrash /user/svcpml/DCS_DataImport/pwFileMatthew.Grant.txt
hdfs dfs -put /home/svcpml/workflow/pwFileMatthew.Grant.txt /user/svcpml/DCS_DataImport/pwFileMatthew.Grant.txt
hdfs dfs -chmod 700 /user/svcpml/DCS_DataImport/pwFileMatthew.Grant.txt

hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.sh
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.sh /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/*.hql
hdfs dfs -put /share/ard_ccv_project_code/SepsisModel/*.hql /projects/ard_ccv_project/DCS/Code/SepsisModel/
hdfs dfs -rm -skipTrash /projects/ard_ccv_project/DCS/Code/SepsisModel/svcpml.keytab
hdfs dfs -put /home/svcpml/workflow/svcpml.keytab /projects/ard_ccv_project/DCS/Code/SepsisModel/svcpml.keytab

#CT
#Run this to start the oozie coordinator
OOZIE_CLIENT_OPTS='-Djavax.net.ssl.trustStore=/etc/pki/java/cacerts' oozie job -oozie https://usamlhdpm06.cotiviti.com:11101/oozie -config /share/ard_ccv_project_code/SepsisModel/SepsisModel_WF.properties  -run

#MNG
