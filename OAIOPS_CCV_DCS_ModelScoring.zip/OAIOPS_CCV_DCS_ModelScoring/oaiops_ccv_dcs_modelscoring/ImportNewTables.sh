#!/bin/bash

export PYTHON_EGG_CACHE=./myeggs
 /usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

#echo "here is the current executing directory"
#dir=$(pwd -P)
#echo $dir
#testDir="/projects/ard_ccv_project/DCS/Data/BCBS_AL/CIS/20171108/"
 
PATTERNA="/projects/ard_ccv_project/DCS/Data/CTRL_STATS/"

PATTERNB="/projects/ard_ccv_project/DCS/Data/COE/"


#echo "heres the final Search Patterns"

COE_HDR="${PATTERNB}/COE_HDR_4Sepsis/${2}/*.parquet"
#echo "file At Path"

COE_HDR=`hadoop fs -ls $COE_HDR  | awk -F'/' '{print $NF}'`
echo "Found: $COE_HDR"


impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -f LoadTablesToImpala.hql --var=Payer=$1 --var=YYYYMMDD=$2 --var=COE_HDRf="$COE_HDR"
