#!/bin/bash




echo "Hello"
SUBJECT=" The DCS pipeline ran successfully"