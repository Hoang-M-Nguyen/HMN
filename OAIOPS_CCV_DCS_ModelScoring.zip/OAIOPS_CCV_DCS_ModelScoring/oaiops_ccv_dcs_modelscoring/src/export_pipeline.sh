#!/bin/bash
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM



python3 Step_09.py
