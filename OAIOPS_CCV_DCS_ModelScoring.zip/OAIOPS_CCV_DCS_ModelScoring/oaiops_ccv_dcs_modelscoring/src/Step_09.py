from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window


#if __name__ == "__main__":
#    if len(sys.argv) != 3:
#        print("Must pass three arguments scores csv, concepttablename, tcube4model tablename", file=sys.stderr)
#        sys.exit(-1)
        
        
    # model_scores_path = sys.argv[0]
    # tcube_concept_table = sys.argv[1]
    # tcube4_model_tableName = sys.argv[2]
spark = (SparkSession.builder
                    .appName("step_09")
                    .config("spark.sql.broadcastTimeout", "360000")
                    .enableHiveSupport()
                    .getOrCreate())

scores_df = spark.sql("select * from scores_model_test")
scores_df = spark.read.format("csv").option("header", "true").load(gConfigValues.model_scores_path)
tcube4_concept_df= spark.read.format("csv").option("header","true").load("hdfs://Atlanta-ml/user/hive/warehouse/ml_ccv_prod.db/tcube4_concept")

#tcube4_concept_df = spark.sql("select * from tcube4_concept")
tcube_pre_final_df = scores_df.join(tcube4_concept_df,Seq("CnlyClaimNum","AccountID","PlatformID","Added","DCSUniqueID","ConceptID"))
tcube_final_df=tcube_final_df.withColumnRenamed("ModelName","ModelID")
tcube_final_df = tcube_pre_final_df.select(tcube_pre_final_df("CnlyClaimNum"),tcube_pre_final_df("DCSUniqueID"),tcube_pre_final_df("ConceptID"),tcube_pre_final_df("ModelScore").cast("float"),tcube_pre_final_df("ModelID"),tcube_pre_final_df("AccountID").cast("integer"),tcube_pre_final_df("Added").cast("integer"),tcube_pre_final_df("PlatformID"))
tcube_final_df.withColumn("ModelAdditiveThreshold",lit(None))
tcube_final_df.withColumn("ModelDeselectorThreshold",lit(None))
tcube_final_df.withColumn("DCSTimeStamp", current_timestamp()).show()

tcube_final_df.withColumn("DCSTimeStamp", current_timestamp()).write.mode("Overwrite").partitionBy("AccountID", "PlatformID", "Added","CnlyClaimNum","ConceptID","ModelID","DCSUniqueID").saveAsTable("tcube4_model")CallRowCountSh("9")gLogger.info(LogMessage("DCS09_Model: COMPLETED"))SendEmail.Send("DCS (SPARK) DCS09_Model", "DCS09_Model step successfully executed.")