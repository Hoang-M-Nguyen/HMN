export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM



proc_JAR_NAME=$1
ENV=$5
SOURCE_DB=$3
TARGET_DB=$4
outputLocation=$2
csv_path=$6



echo "proc_JAR_NAME ENV SOURCE_DB TARGET_DB outputLocation csv_path"



hdfs dfs -get /mlprod/unrestricted/JarRepo/FL/across-fl-ccsr-px-0.0.2.jar



spark-submit --master yarn --queue production --deploy-mode cluster --num-executors 30 --driver-memory 9G --executor-memory 12G --executor-cores 4 --total-executor-cores 120 --class com.cotiviti.ai.fl.px.PxMapping ${proc_JAR_NAME} dcs hive ${SOURCE_DB}.tcube3_proc ${csv_path}/CCSRPX/PRCCSR_v2021-1.CSV ${outputLocation}ccsr_px_features_FL_dcs_score
#spark-submit --master yarn --num-executors 5 --executor-memory 5G --driver-memory 5G --class com.cotiviti.ai.fl.px.PxMapping across-fl-ccsr-px-0.0.2.jar dcs hive ccv_selections.tcube3_proc /mlprod/unrestricted/ml_ccv/data/CCSRPX/PRCCSR_v2021-1.CSV ${outputLocation}ccsr_px_features_FL_dcs_score
#spark-submit --master yarn --conf spark.driver.memory=10G --class com.cotiviti.ai.fl.px.PxMapping --num-executors 2 --executor-memory 10G ${proc_JAR_NAME} dcs hive ${SOURCE_DB}.tcube3_proc ${csv_path}/CCSRPX/PRCCSR_v2021-1.CSV ${outputLocation}ccsr_px_features_FL_dcs_score



hdfs dfs -ls ${outputLocation}ccsr_px_features_FL_dcs_score
/usr/bin/kinit -kt svcdataml.keytab -V svcdataml@COTIVITI.COM



PARQ_LOC="${outputLocation}ccsr_px_features_FL_dcs_score/*.parquet"
ParFileName=`hadoop fs -ls $PARQ_LOC | awk -F'/' '{print $NF}' | head -n 1`
DestDB="ml_ccv_$ENV"
FOLDER_NAME_Proc="TCUBE3_Proc_Blue"

#impala-shell -i gad1phdpml06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Hdr} PURGE;"
#impala-shell -i gad1phdpml06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "invalidate metadata;"
#impala-shell -i gad1phdpml06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/etc/pki/cotiviti/cotiviti.com-allinone.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Hdr} LIKE PARQUET '${outputLocation}test_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}test_dcs_score' ;"

impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Proc} PURGE;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Proc} LIKE PARQUET '${outputLocation}ccsr_px_features_FL_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}ccsr_px_features_FL_dcs_score' ;"


#beeline -u "jdbc:hive2://gad1phdpml03.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" -e "drop table if exists $DestDB.$FOLDER_NAME_Hdr purge;"#beeline -u "jdbc:hive2://gad1phdpml03.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" -e "create table $DestDB.$FOLDER_NAME_Hdr  as select * from $DestDB.$FOLDER_NAME_Hdr;"

#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Hdr} PURGE;"
#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata;"
#impala-shell -i gad1phdpml06.cotiviti.com:21051 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Hdr} LIKE PARQUET '${outputLocation}test_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}test_dcs_score' ;"

