echo "Hello there"

#!/bin/bash
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM
echo `pwd`

hdfs dfs -rm -f /ml$ENV/restricted/ml_ccv/mlworkspace/DCS/last_run_row_counts.txt
hdfs dfs -mv /ml$ENV/restricted/ml_ccv/mlworkspace/DCS/todays_row_counts.txt /ml$ENV/restricted/ml_ccv/mlworkspace/DCS/last_run_row_counts.txt

#${RESTRICTION}=unrestricted
if [ ${ENV} == "prod" ]; then

    hdfs dfs -rm -r /ml$ENV/unrestricted/ml_ccv/mlworkspace/CV_MS_007/Scoring_dcs/CV_MS_007v1_dcs
	spark-submit --master yarn --deploy-mode cluster --driver-memory 40G --executor-memory 16G --executor-cores 4 --files=/etc/hive/conf/hive-site.xml CV_MS_007v1_dcs.jar $ENV unrestricted
    sh DR_batch_scoring_coe.sh CV_MS_007 ${DR_ID_CV_MS_007v1} ${API_KEY} v1_dcs $ENV

    hdfs dfs -rm -r /ml$ENV/unrestricted/ml_ccv/mlworkspace/DRG870to872/Scoring_dcs/DRG870to872v1_dcs
    spark-submit --master yarn --deploy-mode cluster --driver-memory 40G --executor-memory 16G --executor-cores 4 --files=/etc/hive/conf/hive-site.xml DRG870to872v1_dcs.jar $ENV unrestricted
    sh DR_batch_scoring_coe.sh DRG870to872 ${DR_ID_DRG870to872v1} ${API_KEY} v1_dcs $ENV

fi
