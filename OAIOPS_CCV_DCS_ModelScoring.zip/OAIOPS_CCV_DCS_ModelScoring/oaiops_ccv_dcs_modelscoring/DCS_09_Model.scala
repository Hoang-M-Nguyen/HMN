package ProcessSteps

import App.Arguments
import App.Utilities._
import org.apache.spark.sql.functions.current_timestamp

import java.util.{Calendar, Properties}
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.kafka.clients.consumer.{ConsumerConfig, ConsumerRecords, KafkaConsumer}
import org.apache.kafka.common.serialization._
import org.joda.time.DateTime

import java.time.Duration
import scala.collection.JavaConverters._
import scala.math.Ordered.orderingToOrdered
// ML SPECIFIC IMPORTS

object DCS09_Model {

  // ***********************************************************************************************************************************************************************************************************
  // ***********************************************************************************************************************************************************************************************************
  // NOTES
  // ***********************************************************************************************************************************************************************************************************
  // ***********************************************************************************************************************************************************************************************************

  /*
  NOTES
    The idea is to dynamically run all active models on the concept results and get back a vertical list of model scores.
    There can be > 1 concept per claim and > 1 model per concept

  STEP 1: START WITH THESE BASE TABLES
   driver_model    (this is a list of the models)
   tcube4_concept  (this is the table we're scoring)
   tcube3_hdr      (header-level enhanced data)
   tcube3_dtl      (detail-level enhanced data)
   tcube4_diag     (diag level enchanced data)
   tcube3_proc     (proc level enhanced data)

  STEP 2: RUN ALL ACTIVE MODELS
   "Active" is defined by where ModelStatus = 330 in the driver_model hive table

  STEP 3: GATHER ALL MODEL RESULTS INTO ONE HIVE TABLE
   Name the table: tcube4_model_test
   Partition the table by AccountID + Added
   Table should have the following fields:
      AccountID
      Added
      CnlyClaimNum
      DCSUniqueID
      ConceptID
      ModelID ***
      ModelScore
      DCSTimeStamp
   *** You can use "ModelName" in this field for now because that's how the old process is done, but I'd love to get this standardized into ModelID and maybe even build all the new models under the ModelID and not ModelName)

  NOTE ABOUT DRIVER_MODEL TABLE
   This is an example of how I want this table to work, but fields are not set in stone.
   I would love to get all the ModelID's standardized into an MXXXX format so you can programmatically build locations for the jsons/jars etc. based on the ModelID with no hard coding at all

  EXAMPLE OF JOIN TO GET CLAIM FIELDS ON TO CONCEPT RESULTS
   (example because everything is partitioned by AccountID + Added, left joining b/c we're only running models on concept results)
   SELECT
     h.<whatever fields you need for a model parameter from claim header>
     c.<whatever fields you need for a model parameter from concept table>
    FROM
      tcube4_concept c
      LEFT JOIN tcube3_hdr h
          ON  c.AccountID    = h.AccountID
          AND c.Added        = h.Added
          AND c.CnlyClaimNum = h.CnlyClaimNum
          AND c.DCSUniqueID  = h.DCSUniqueID
    WHERE
      c.ConceptID = 'CV_MS_007'

  NOTE ABOUT THE HIVE DATABASE
  For development right now, all tables are in ccv_selections, but the hope is to have 3 new databases and the location will be set when DCS starts
      dcs_dev
      dcs_test
      dcs_prod
  In other words, avoid hard coding anything with "ccv_selections"

  PURPOSE
  1. Run machine learning models on all concept results
  2. Output: tcube_model_[DCSRun]
  3. Merge ExpectedId & Model Scores
  4. Output: tcube_score_[DCSRun]

  TYPES OF MODELS:
  1. Standard: Generates a score and an ExpectedIDAmt that can be sorted into regular DCSExpectedIDAmt
  2. Concept Deselector: if ClaimID+ConceptID+ModelID < .### then remove the whole ClaimID+ConceptID from contention
  3. Claim Deselector: if ModelAgnostic score < .### then remove the whole ClaimID from contention
  4. Limit override: if ModelAgnositc score < .### then override Cotiviti-set limits

  Model code is stored in here:
  /projects/ard_ccv_project/DCS/Code/SepsisModel

  https://gitlab.cotiviti.com/MLPlatform/ccv/ccv_workflow
  https://gitlab.cotiviti.com/MLPlatform/ccv/ccv_workflow/blob/develop/lib/platformScoring.sh

  */

  gLogger.info(LogMessage("DCS09_Model: STARTED"))

  def apply(database: String,environment_name:String) {
    try {
      var topicName : String = ""
      var serversConfig : String = ""
      var groupIDConfig : String = ""
      var autoOffsetResetConfig : String = ""
      var enableAutoCommitConfig : String = ""

      environment_name.toUpperCase match {
        case "DEV" =>
          topicName = gConfigValues.devKafkaTopicName
          serversConfig = gConfigValues.devKafkaServersConfig
          groupIDConfig = gConfigValues.devKafkaConsumerGroupIDConfig
          autoOffsetResetConfig = gConfigValues.devKafkaAutoOffsetResetConfig
          enableAutoCommitConfig = gConfigValues.devKafkaEnableAutoCommitConfig
        case "TEST" =>
          topicName = gConfigValues.testKafkaTopicName
          serversConfig = gConfigValues.testKafkaServersConfig
          groupIDConfig = gConfigValues.testKafkaConsumerGroupIDConfig
          autoOffsetResetConfig = gConfigValues.testKafkaAutoOffsetResetConfig
          enableAutoCommitConfig = gConfigValues.testKafkaEnableAutoCommitConfig
        case "PROD" =>
          topicName = gConfigValues.prodKafkaTopicName
          serversConfig = gConfigValues.prodKafkaServersConfig
          groupIDConfig = gConfigValues.prodKafkaConsumerGroupIDConfig
          autoOffsetResetConfig = gConfigValues.prodKafkaAutoOffsetResetConfig
          enableAutoCommitConfig = gConfigValues.prodKafkaEnableAutoCommitConfig
        case "ALEX" =>
          topicName = gConfigValues.alexKafkaTopicName
          serversConfig = gConfigValues.alexKafkaServersConfig
          groupIDConfig = gConfigValues.alexKafkaConsumerGroupIDConfig
          autoOffsetResetConfig = gConfigValues.alexKafkaAutoOffsetResetConfig
          enableAutoCommitConfig = gConfigValues.alexKafkaEnableAutoCommitConfig
        case _ =>
          gLogger.error(LogMessage("Kafka configs not exists for environment:" + environment_name))
          System.exit(1)
      }
      gLogger.info(LogMessage("Kafka Topic Name:" + topicName))
      gLogger.info(LogMessage("Kafka serversConfig:" + serversConfig))
      gLogger.info(LogMessage("Kafka groupIDConfig:" + groupIDConfig))
      gLogger.info(LogMessage("Kafka autoOffsetResetConfig:" + autoOffsetResetConfig))
      gLogger.info(LogMessage("Kafka enableAutoCommitConfig:" + enableAutoCommitConfig))

      val producerProps = new Properties()
      producerProps.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, serversConfig)
      producerProps.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, classOf[StringSerializer].getName)
      producerProps.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, classOf[StringSerializer].getName)
      val kafkaProducer = new KafkaProducer[String, String](producerProps)
      kafkaProducer.send(new ProducerRecord[String, String](topicName, ""))//type message for value here that need to send to kafka
      kafkaProducer.flush()
      gLogger.info(LogMessage("Kafka message sent."))

      val consumerProps = new Properties()
      consumerProps.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, serversConfig)
      consumerProps.setProperty(ConsumerConfig.GROUP_ID_CONFIG, groupIDConfig)
      consumerProps.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetResetConfig)
      consumerProps.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, classOf[StringSerializer].getName)
      consumerProps.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, classOf[StringSerializer].getName)
      consumerProps.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, enableAutoCommitConfig)

      val consumer = new KafkaConsumer[String, String](consumerProps)
      consumer.subscribe(List(topicName).asJava)

      val beforeConsumerLoopTime = DateTime.now
      gLogger.info(LogMessage("beforeConsumerLoopTime:" +  beforeConsumerLoopTime.toString()))

      var isStillLoop = true
      while(isStillLoop)
      {
        val polledRecords: ConsumerRecords[String, String] = consumer.poll(Duration.ofSeconds(1))
        if(!polledRecords.isEmpty)
        {
          val recordIterator = polledRecords.iterator()
          while(recordIterator.hasNext)
          {
            val record = recordIterator.next()
            if(record.key() == gConfigValues.ConsumerKeyMatch && record.value() == gConfigValues.ConsumerValueMatch)
            {
              isStillLoop = false
              gLogger.info(LogMessage("kafka consumer key:" + record.key() + "; Value:" + record.value()))
            }
          }
        }

        val now = DateTime.now
        gLogger.info(LogMessage("in consumer loop now:" +  now.toString()))
        val addHoursToBreak = beforeConsumerLoopTime.plusMinutes(gConfigValues.ModelsMaxWaitInMinutes.toInt)
        if(addHoursToBreak.isBefore(now))
        {
          gLogger.warn(LogMessage("Models did not finished in defined time:" + gConfigValues.ModelsMaxWaitInMinutes))
          isStillLoop = false
        }
      }

      
            DCS09_ModelOozie(database,environment_name)

          val scores_df = spark.sql("select * from scores_model_test")
           val scores_df = gSparkSession.read.format("csv").option("header", "true")
                .load(gConfigValues.model_scores_path)

            val tcube4_concept_df = gSparkSession.sql("select * from tcube4_concept")
            val tcube_pre_final_df = scores_df.as("s").join(tcube4_concept_df.as("t"),
              Seq("CnlyClaimNum","AccountID","PlatformID","Added","DCSUniqueID","ConceptID")
            )

            val tcube_final_df = tcube_pre_final_df.select(
              tcube_pre_final_df("CnlyClaimNum"),
              tcube_pre_final_df("DCSUniqueID"),
              tcube_pre_final_df("ConceptID"),
              tcube_pre_final_df("ModelScore").cast("float"),
              tcube_pre_final_df("ModelName"),
              tcube_pre_final_df("AccountID").cast("integer"),
              tcube_pre_final_df("Added").cast("integer"),
              tcube_pre_final_df("PlatformID")
            )


            tcube_final_df.
              withColumn("DCSTimeStamp", current_timestamp()).
              write.mode("Overwrite").
              partitionBy("AccountID", "PlatformID", "Added").
              saveAsTable("tcube4_model")
            CallRowCountSh("9")
            gLogger.info(LogMessage("DCS09_Model: COMPLETED"))
            SendEmail.Send("DCS (SPARK) DCS09_Model", "DCS09_Model step successfully executed.")*/
    }
    catch {
      case ex: Exception => {
        gLogger.error(LogMessage("DCS09_Model step failed"), ex)
        SendEmail.Send("FAILED: DCS09_Model Step in DCS Run", "DCS09_Model Step failed.  Please look in to the log for more details.")
        System.exit(1)
      }
    }
  }
}