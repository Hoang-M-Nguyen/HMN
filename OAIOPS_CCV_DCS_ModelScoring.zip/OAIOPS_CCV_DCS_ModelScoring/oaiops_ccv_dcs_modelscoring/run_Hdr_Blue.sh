#!/usr/bin/env bash
set -vx
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

hdr_JAR_NAME=$1
ENV=$2
SOURCE_DB=$3
TARGET_DB=$4
outputLocation=$5

#hdfs dfs -get /mlprod/unrestricted/JarRepo/FL/${hdr_JAR_NAME}

spark-submit --master yarn --queue production --deploy-mode cluster --num-executors 30 --driver-memory 9G --executor-memory 12G --executor-cores 4 --total-executor-cores 120 --class com.cotiviti.ai.fl.COEHdrDCS ${hdr_JAR_NAME} score hive ${SOURCE_DB}.tcube3_hdr ${SOURCE_DB}.tcube4_concept ${outputLocation}test_dcs_score ${outputLocation}test_dcs_score_backup 2
#spark-submit --master yarn --num-executors 50 --executor-memory 5G --driver-memory 5G --class com.cotiviti.ai.fl.COEHdrDCS ${hdr_JAR_NAME} score hive ccv_selections.cube_hdr ccv_selections.cube_concept /mlprod/restricted/ml_ccv/DCS/Scoring_Data/COE_Hdr /mlprod/restricted/ml_ccv/DCS/Scoring_Data/COE_Hdr_backup 2

/usr/bin/kinit -kt svcdataml.keytab -V svcdataml@COTIVITI.COM

#/usr/bin/kinit -kt svcdataml.keytab -V svcdataml@COTIVITI.COM


PARQ_LOC="${outputLocation}test_dcs_score/*.parquet"
ParFileName=`hadoop fs -ls $PARQ_LOC | awk -F'/' '{print $NF}' | head -n 1`
DestDB="ml_ccv_$ENV"
FOLDER_NAME_Hdr="TCUBE3_Hdr_Blue"

impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "DROP TABLE IF EXISTS ${DestDB}.${FOLDER_NAME_Hdr} PURGE;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "invalidate metadata;"
impala-shell -i usamlhdpm06.cotiviti.com:21001 -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/rootint.pem -q "CREATE EXTERNAL TABLE ${DestDB}.${FOLDER_NAME_Hdr} LIKE PARQUET '${outputLocation}test_dcs_score/${ParFileName}' STORED AS PARQUET LOCATION '${outputLocation}test_dcs_score' ;"