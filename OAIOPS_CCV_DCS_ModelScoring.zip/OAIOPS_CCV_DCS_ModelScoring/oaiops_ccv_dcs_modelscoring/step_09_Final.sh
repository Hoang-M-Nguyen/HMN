#!/bin/bash
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

ENV=$1

hdfs dfs -cat /ml${ENV}/unrestricted/ml_ccv/DCS/oozie/run_dcs_test_faviana.sh|exec bash -s $ENV 9 9