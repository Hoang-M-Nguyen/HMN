#!/bin/bash
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM



ENV=$1


#combine and push new models
hdfs dfs -rm -f /ml$ENV/unrestricted/ml_ccv/DCS/models/NewScoreFormatExport.csv
rm -f NewScoreFormatExport.csv
#hdfs dfs -cat /ml$ENV/restricted/ml_ccv/mlworkspace/*/Predictions/*Scored.csv >> NewScoreFormatExport.csv
hdfs dfs -cat /ml${ENV}/unrestricted/ml_ccv/mlworkspace/*/Predictions_dcs/*Scored.csv >> NewScoreFormatExport.csv


#sed -i '/CnlyClaimNum/d' NewScoreFormatExport.csv
hdfs dfs -put NewScoreFormatExport.csv /ml$ENV/unrestricted/ml_ccv/DCS/models/NewScoreFormatExport.csv



