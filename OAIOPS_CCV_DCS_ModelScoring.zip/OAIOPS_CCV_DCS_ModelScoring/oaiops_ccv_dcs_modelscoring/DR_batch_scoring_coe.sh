#!/bin/bash
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM
echo `pwd`

${ENV}=prod

Model_Name=$1
DR_Model_ID=$2
API_Token_ID=$3
Model_Version=$4
ENV=$5
Batch_Prediction_URL=http://usapmldrobo03.cotiviti.com/api/v2/batchPredictions



#/mlprod/restricted/ml_ccv/mlworkspace/DRG065/Scoring



echo "Pulling CSV from /ml${ENV}/unrestricted/ml_ccv/mlworkspace/$Model_Name/Scoring_dcs/$Model_Name${Model_Version} ${Model_Name}_features.csv"
#rm ${Model_Name}_features.csv
hdfs dfs -getmerge /ml${ENV}/unrestricted/ml_ccv/mlworkspace/$Model_Name/Scoring_dcs/$Model_Name${Model_Version} ${Model_Name}_features.csv



#rm ${Model_Name}${Model_Version}_Scored.csv
hdfs dfs -rm /ml${ENV}/unrestricted/ml_ccv/mlworkspace/$Model_Name/Predictions_dcs/*
#hdfs dfs -mv /ml${ENV}/restricted/ml_ccv/mlworkspace/$Model_Name/Predictions/${Model_Name}${Model_Version}_Scored.csv /ml${ENV}/restricted/ml_ccv/mlworkspace/$Model_Name/Predictions/${Model_Name}${Model_Version}_Scored_`date +"%m-%d-%y"`.csv



echo "Starting batch scoring"
/usr/local/bin/batch_scoring_deployment_aware --host=http://usapmldrobo05.cotiviti.com/ --user=$USER $DR_Model_ID ${Model_Name}_features.csv --api_token=$API_Token_ID --out=${Model_Name}${Model_Version}_Scored.csv --pred_name="ModelScore" --keep_cols="CnlyClaimNum,ModelName,DCSUniqueID,ConceptID,AccountID,PlatformID" --no-resume --encoding="utf-8"




echo "Moving scores to /ml${ENV}/unrestricted/ml_ccv/mlworkspace/$Model_Name/Predictions_dcs/${Model_Name}${Model_Version}_Scored.csv"
hdfs dfs -put -f ${Model_Name}${Model_Version}_Scored.csv /ml${ENV}/unrestricted/ml_ccv/mlworkspace/$Model_Name/Predictions_dcs/${Model_Name}${Model_Version}_Scored.csv



Feature_Rows=0
Scored_Rows==0



Feature_Rows=`wc -l ${Model_Name}_features.csv  | cut -d " " -f1`
echo $Feature_Rows
Scored_Rows=`wc -l ${Model_Name}${Model_Version}_Scored.csv  | cut -d " " -f1`
echo $Scored_Rows
echo "${Feature_Rows}|${Model_Name}_features.csv|${Scored_Rows}|${Model_Name}${Model_Version}_Scored.csv"
echo "${Feature_Rows}|${Model_Name}_features.csv|${Scored_Rows}|${Model_Name}${Model_Version}_Scored.csv
" | hdfs dfs -appendToFile - /ml$ENV/restricted/ml_ccv/mlworkspace/DCS/todays_row_counts.txt
