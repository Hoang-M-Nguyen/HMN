#!/bin/bash

# Environment Setup


if [ "$#" -eq 0 ];  then
        echo "no input file "
        echo "Please use one of these .env-dev or .env-mvp or .env-prod"
else
    ifile="$1"
    #substitue comments from // to # then remove comments substitue env. with export then write to localenv
sed 's/\/\//#/g' "$ifile" | sed 's/#.*.*//g' | sed 's/env./export /g'  >localenv

#load localenv as new env variables
. localenv
# Deployment setup

# output directory delete and create with input file


#a=$(find local-* -type d | wc -l)


#remove deploy folder
echo "removing deployment folder"
    rm -r local-*



# build new directory name

dpdir=local-$(echo "$ifile" | rev | cut -d'.' -f 1 | rev)
mkdir "$dpdir"

# if using .env-dev file
# exclude the following files
# \( ! -iname ".env-mvp" ! -iname ".env-prod" ! -iname "jenkinsfile" !  -iname "localenv" !  -iname ".env-dev" ! -iname "loadenv.sh" \)
# exclude the following folders
# \( ! -path "./.git/*" ! -path "./.env-mvp/*" ! -path "./.env-prod/*" ! -path "./local-*/*" \)


        if [ "$ifile" = ".env-dev" ];  then
            #echo "Env is $ifile"
            for file in $(find . -type f \( ! -iname ".env-mvp" ! -iname ".env-prod" ! -iname "jenkinsfile" !  -iname "localenv" !  -iname ".env-dev" ! -iname "loadenv.sh" \) \( ! -path "./.git/*" ! -path "./.env-mvp/*" ! -path "./.env-prod/*" ! -path "./local-*/*" \) )
            do
               # echo "file $file"
                if [[ $file == *.jar ]]; then
                   # echo "$file matches pattern '*.jar'"
                    rsync -a "$file" "$dpdir"
                else
                SUBSTRING=$(echo "$file" | rev | cut -d'/' -f 1 | rev)
                envsubst < "$file" > "$dpdir"/"$SUBSTRING"
                fi

            done
        fi

       if [ "$ifile" = ".env-mvp" ];  then
            #echo "Env is $ifile"
            for file in $(find . -type f \( ! -iname ".env-mvp" ! -iname ".env-prod" ! -iname "jenkinsfile" !  -iname "localenv" !  -iname ".env-dev" ! -iname "loadenv.sh" \) \( ! -path "./.git/*" ! -path "./.env-dev/*" ! -path "./.env-prod/*" ! -path "./local-*/*" \) )
            do
               # echo "file $file"
                if [[ $file == *.jar ]]; then
                   # echo "$file matches pattern '*.jar'"
                    rsync -a "$file" "$dpdir"
                else
                SUBSTRING=$(echo "$file" | rev | cut -d'/' -f 1 | rev)
                envsubst < "$file" > "$dpdir"/"$SUBSTRING"
                fi

            done
        fi
       if [ "$ifile" = ".env-prod" ];  then
            #echo "Env is $ifile"
            for file in $(find . -type f \( ! -iname ".env-mvp" ! -iname ".env-prod" ! -iname "jenkinsfile" !  -iname "localenv" !  -iname ".env-dev" ! -iname "loadenv.sh" \) \( ! -path "./.git/*" ! -path "./.env-mvp/*" ! -path "./.env-dev/*" ! -path "./local-*/*" \) )
            do
               # echo "file $file"
                if [[ $file == *.jar ]]; then
                   # echo "$file matches pattern '*.jar'"
                    rsync -a "$file" "$dpdir"
                else
                SUBSTRING=$(echo "$file" | rev | cut -d'/' -f 1 | rev)
                envsubst < "$file" > "$dpdir"/"$SUBSTRING"
                fi

            done
        fi


fi









