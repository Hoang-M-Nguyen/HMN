#!/bin/bash
set -e
export PYTHON_EGG_CACHE=./myeggs
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

Job_Name=$1
DataBase=$2
Table_Name=$3
concurrency=$4
echo "The concurrency is set to $concurrency"
query1="
set hive.txn.manager = org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
select job_id  from "$DataBase"."$Table_Name" where job_name='"$Job_Name"' and status ='Running' ;"
echo $query1
/usr/bin/beeline -u "jdbc:hive2://usamlhdpm02.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" --showHeader=false -e "$query1" "--outputformat=csv2" > "job_id.txt"
sed -i '1d;$d' job_id.txt
sed  -i s/\|//g job_id.txt
sed  -i s/\ //g job_id.txt
tr '\n' ',' < job_id.txt >job_id1.txt
sed -i s/.$// job_id1.txt
job_id_OUTPUT=$(cat job_id1.txt)
if  [ -z "$job_id_OUTPUT" ] || [ $concurrency == "true" ];
then
echo "output=success"
else
echo "job_id_Running=$job_id_OUTPUT"
echo "output=$job_id_OUTPUT"
fi
