#!/bin/bash
set -e
export PYTHON_EGG_CACHE=./myeggs
#export SPARK_HOME=/opt/cloudera/parcels/CDH-6.3.3-1.cdh6.3.3.p3807.2132412/lib/spark
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

#source query_trigger_Running_1.sh
WF_ID=${JOB_ID}
echo The Job id is $WF_ID
Event_Name=$OAI_OPS_Event
echo The Event name  is  $Event_Name
Start_Time=$(date +'%m/%d/%Y %T')
Status=Running

echo using ${OAI_OPS_DB} database
current_s_no=$(cat trigger_s_no.txt)
rm -rf trigger_s_no.txt
echo max value is $current_s.no
query="set hive.support.concurrency=true;
set hive.enforce.bucketing=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
set hive.compactor.initiator.on=true;
set hive.compactor.worker.threads=1;
update  ${OAI_OPS_DB}.${OAI_OPS_event_Table_Name}  set Status='Finished',end_time=from_unixtime(unix_timestamp()) where WF_ID='${WF_ID}' and Event_Name ='${Event_Name}' and event_trig_s_no='${current_s_no}';"
echo $query
/usr/bin/beeline -u "jdbc:hive2://usamlhdpm02.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" --showHeader=false -e "$query"
