
----------------------------------------------------

OAI_OPS_AUDIT is a workflow which is integrated with any workflow to track the information
.
----------------------------------------------------

In this workflow, the below information is captured into a hive table which can 
have a single point of 
reference to look across for a given day or daily basis.

1. workflow ID

2. Project Name

3. Start time of Workflow

4. status of Workflow

5. End Time of Workflow

6. Error information


Concurrency Handelling:
We have a flag "allow_concurrenct_run" in properties file 
 which can decide running same work-flow with 
status "Running" for a given project paralelly.

The default value is "false". 

If "allow_concurrenct_run" is set to "true" then the  pipeline allows 
executing same work-flows parallelly
.
If "allow_concurrenct_run" is set to "false" then the pipeline blocks 
executing the next parallel work-flows and
make an entry in hive table with error information 
as 
"Unable to start workflow since job-id - 0973158-210202122525611-oozie-oozi-W is in "Running" status".


keys which are mandatory in properties file; for running the batch based audit work-flows are as below.

1.OAI_OPS_Project=${NameNode}/ml${ENV}/unrestricted/oai_ops/mlworkspace/oaiopstracker/workflow
	
This is the location where all sub workflows ,shell and sql scripts are placed

2.allow_concurrenct_run=false
	 
This controls parallel behaviour of same workflows with status as Running

3.OAI_OPS_DB=default
	
This is the name of the database in which  the batch or event trigger tables are located 

4.OAI_OPS_Table_Name=workflow_job_audit	
This is the name of the batch trigger table. Here we capture all the matrix of the batch workflow

5.Project_Name=${Project}
	
This is the name of the workflow

6.User =${UserName}
	
This holds the information of which user is running the workflow.

7.Hive_Site=/etc/hive/conf/hive-site.xml
	
This holds the location of hive-site.xml file


keys which are mandatory in properties file; for running the event based audit work-flows are as below.

1.OAI_OPS_Project=${NameNode}/ml${ENV}/unrestricted/oai_ops/mlworkspace/oaiopstracker/workflow
	
This is the location where all sub workflows ,shell and sql scripts are placed

2.OAI_OPS_Event=dupes_odar
	
This is the name of event for given project

3.allow_concurrenct_run=true
	
 This controls parallel behavior of same workflows with status as Running
4.OAI_OPS_DB=default
	
This is the name of the database in which  the batch or event trigger tables are located 

5.OAI_OPS_event_Table_Name=workflow_event_trigger_job_audit
	
This is the name of the event  trigger table. Here we capture all the matrix of 
the event based  workflow

6.Project_Name=${Project}

	This is the name of the workflow

7.User =${UserName}
	
This holds the information of which user is running the workflow.

8.Hive_Site=/etc/hive/conf/hive-site.xml
	
This holds the location of hive-site.xml file

