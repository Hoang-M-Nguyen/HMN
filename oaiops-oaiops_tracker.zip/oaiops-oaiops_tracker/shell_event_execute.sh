#!/bin/bash
set -vx
export PYTHON_EGG_CACHE=./myeggs
 /usr/bin/kinit -kt ${USER}.keytab -V ${USER}@COTIVITI.COM
#source /home/vinay.kona/share/subWF/event_config
##################ARGUMENTS#############

JOB_ID="1"
JOB_Type=$6
Job_Name=$1
ProcessID=$2
ENV=$7
JobLoc=$(hostname)
Status=$3
Event_Name=${Job_Name}_${Status}
Event_Trigger_Time=$(date +"%Y-%m-%d %H:%M:%S")
#Event_Seq_No=${10}
Upstream_Event=$4
Downstream_Event=$5
executionType="shell"
ExecCommand="PROXY"
Prioritiy="Normal"
SLA="NA"
UserName=$USER
Job_Owner=$8
HOST=$9
ERRORMessage=${10}   #Always keeps as last argument

########################################
if [ $Status = "Start" ];
then
echo "the event s.no calucation started"
event_counts="
select max(Event_Seq_No) from ${OAI_OPS_DB}.${OAI_OPS_Table_Name} where ProcessID='${ProcessID}' and Job_Type='Event_WF_Triggered_Shell_Script';"
echo $event_counts
/usr/bin/beeline -u "jdbc:hive2://usamlhdpm02.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" --showHeader=false -e "$event_counts" "--outputformat=csv2" > "tmp_s_no.txt"
sed -i '1d;$d' tmp_s_no.txt
sed  -i s/\|//g tmp_s_no.txt
sed  -i s/\ //g tmp_s_no.txt
tr '\n' ',' < tmp_s_no.txt >tmp_s_no1.txt
sed -i s/.$// tmp_s_no1.txt
max_s_no=$(cat tmp_s_no1.txt)
#rm -rf tmp_s_no1.txt tmp_s_no.txt
Event_Seq_No=$((max_s_no+1))
echo The serial number for event is ${Event_Seq_No}
else
max_s_no=$(cat tmp_s_no1.txt)
Event_Seq_No=$((max_s_no+1))
rm -rf tmp_s_no1.txt tmp_s_no.txt
fi

passPath="/user/$USER/pwFile$USER.txt"
#HOST="https://usaprdlenses01.cotiviti.com:9991"
echo "your pass path is: $passPath"
echo $configuration
echo "your host name is: $HOST"

pass=$(hdfs dfs -cat "$passPath")

TOKEN=$(curl -X POST -H "Content-Type:application/json" -d {\"user\":\"$USER\"','\"password\":\"$pass\"} ${HOST}/api/login )


curl -H "X-Kafka-Lenses-Token:$TOKEN" --request POST --data '[
    {
           "key": 4524334,
                                "value": {
                                                "Job_ID":"'"$JOB_ID"'",
                                                "Job_Type":"'"$JOB_Type"'",
                                                "Job_Name":"'"$Job_Name"'",
                                                "Job_Owner":"'"$Job_Owner"'",
                                                "ProcessID":"'"$ProcessID"'",
                                                "ErrorMessage":"'"$ERRORMessage"'",
                                                "Env":"'"$ENV"'",
                                                "JobLoc": "'"$JobLoc"'",
                                                "UserName": "'"$UserName"'",
                                                "Event_Name":"'"$Event_Name"'",
                                                "Event_Trigger_Time": "'"$Event_Trigger_Time"'",
                                                "Status": "'"$Status"'",
                                                "Event_Seq_No": "'"$Event_Seq_No"'",
                                                "Upstream_Event": "'"$Upstream_Event"'",
                                                "Downstream_Event": "'"$Downstream_Event"'",
                                                "executionType": "'"$executionType"'",
                                                "ExecCommand": "'"$ExecCommand"'",
                                                "Prioritiy": "'"$Prioritiy"'",
                                                "SLA": "'"$SLA"'"

        }
        }
]' "$HOST/api/jdbc/insert/prepared/OpsEvent?kt=INTEGER&vt=AVRO"
