#!/bin/bash
set -e
export PYTHON_EGG_CACHE=./myeggs
#export SPARK_HOME=/opt/cloudera/parcels/CDH-6.3.3-1.cdh6.3.3.p3807.2132412/lib/spark
/usr/bin/kinit -kt $USER.keytab -V $USER@COTIVITI.COM

WF_ID=$JOB_ID
echo The Job id is  $WF_ID
Event_Name=$OAI_OPS_Event
echo The Event name  is  $Event_Name
Start_Time=$(date +'%m/%d/%Y %T')
Status=Running

echo using ${OAI_OPS_DB} database
max_query="
set hive.txn.manager = org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
select count(1) from ${OAI_OPS_DB}.${OAI_OPS_event_Table_Name} where WF_ID='${WF_ID}';"
echo $max_query
/usr/bin/beeline -u "jdbc:hive2://usamlhdpm02.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" --showHeader=false -e "$max_query" "--outputformat=csv2" > "tmp_s_no.txt"
sed -i '1d;$d' tmp_s_no.txt
sed  -i s/\|//g tmp_s_no.txt
sed  -i s/\ //g tmp_s_no.txt
tr '\n' ',' < tmp_s_no.txt >tmp_s_no1.txt
sed -i s/.$// tmp_s_no1.txt
max_s_no=$(cat tmp_s_no1.txt)
rm -rf tmp_s_no1.txt tmp_s_no.txt
current_s_no=$((max_s_no+1))
 echo $current_s_no >> "trigger_s_no.txt"
echo current s.no  is $current_s_no
query="set hive.support.concurrency=true;
set hive.enforce.bucketing=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
set hive.compactor.initiator.on=true;
set hive.compactor.worker.threads=1;
insert into ${OAI_OPS_DB}.${OAI_OPS_event_Table_Name}  PARTITION (Start_Time) select '${WF_ID}','${Event_Name}','${current_s_no}','','Running','',from_unixtime(unix_timestamp()) as Startt_Time from (select 'dummy') x;"
echo $query
/usr/bin/beeline -u "jdbc:hive2://usamlhdpm02.cotiviti.com:10000/default;principal=hive/usamlhdpm02@COTIVITI.COM" --showHeader=false -e "$query"
