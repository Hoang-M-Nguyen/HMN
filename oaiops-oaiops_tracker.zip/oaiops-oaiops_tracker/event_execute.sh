#!/bin/bash

export PYTHON_EGG_CACHE=./myeggs
 /usr/bin/kinit -kt ${USER}.keytab -V ${USER}@COTIVITI.COM

##################ARGUMENTS#############

JOB_ID="1"     
JOB_Type=$6
Job_Name=$1
ProcessID=$2
ENV=$7
JobLoc=$(hostname)
Status=$3
Event_Name=${Job_Name}_${Status}
Event_Trigger_Time=$(date +"%Y-%m-%d %H:%M:%S")
Event_Seq_No="1"
Upstream_Event=$4
Downstream_Event=$5
executionType="shell"
ExecCommand="PROXY"
Priority="Normal"
SLA="NA"
UserName=$USER
Job_Owner=$8
HOST=$9
ERRORMessage=${10}   #Always keeps as last argument

########################################


passPath="/user/$USER/pwFile$USER.txt"
#HOST="https://usaprdlenses01.cotiviti.com:9991"
echo "your pass path is: $passPath"

echo "your host name is: $HOST"

pass=$(hdfs dfs -cat "$passPath")

TOKEN=$(curl -X POST -H "Content-Type:application/json" -d {\"user\":\"$USER\"','\"password\":\"$pass\"} ${HOST}/api/login )


curl -H "X-Kafka-Lenses-Token:$TOKEN" --request POST --data '[
    {
           "key": 4524334,
                                "value": {
                                                "Job_ID":"'"$JOB_ID"'",
                                                "Job_Type":"'"$JOB_Type"'",
                                                "Job_Name":"'"$Job_Name"'",
                                                "Job_Owner":"'"$Job_Owner"'",
                                                "ProcessID":"'"$ProcessID"'",
                                                "ErrorMessage":"'"$ERRORMessage"'",
                                                "Env":"'"$ENV"'",
                                                "JobLoc": "'"$JobLoc"'",
                                                "UserName": "'"$UserName"'",
                                                "Event_Name":"'"$Event_Name"'",
                                                "Event_Trigger_Time": "'"$Event_Trigger_Time"'",
                                                "Status": "'"$Status"'",
                                                "Event_Seq_No": "'"$Event_Seq_No"'",
                                                "Upstream_Event": "'"$Upstream_Event"'",
                                                "Downstream_Event": "'"$Downstream_Event"'",
                                                "executionType": "'"$executionType"'",
                                                "ExecCommand": "'"$ExecCommand"'",
                                                "Priority": "'"$Priority"'",
                                                "SLA": "'"$SLA"'"

        }
        }
]' "$HOST/api/jdbc/insert/prepared/OpsEvent?kt=INTEGER&vt=AVRO"
